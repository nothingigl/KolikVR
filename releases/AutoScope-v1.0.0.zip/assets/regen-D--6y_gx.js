import{build as i}from"./energy-DgBtlfMx.js";import"./primitives-B-iT0ngw.js";import"./three-BUbp3WSG.js";const m=i;export{m as build};
